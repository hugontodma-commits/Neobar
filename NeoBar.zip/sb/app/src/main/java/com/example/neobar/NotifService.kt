package com.example.neobar
import android.graphics.drawable.Drawable
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifService : NotificationListenerService() {
    companion object { var onChange: ((List<Drawable>) -> Unit)? = null; var inst: NotifService? = null }
    override fun onListenerConnected() { inst = this; push() }
    override fun onNotificationPosted(s: StatusBarNotification) = push()
    override fun onNotificationRemoved(s: StatusBarNotification) = push()
    private fun push() {
        val icons = (activeNotifications ?: return).filter { it.isClearable || true }
            .mapNotNull { runCatching { it.notification.smallIcon.loadDrawable(this) }.getOrNull() }
            .distinct()
        onChange?.invoke(icons)
    }
}
