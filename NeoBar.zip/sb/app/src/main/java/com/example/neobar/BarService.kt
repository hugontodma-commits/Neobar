package com.example.neobar
import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.*
import android.net.*
import android.os.*
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class BarService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var bar: LinearLayout
    private lateinit var left: LinearLayout
    private lateinit var clock: TextView
    private lateinit var bt: ImageView; private lateinit var net: ImageView
    private lateinit var sig: ImageView; private lateinit var batt: ImageView
    private val h = Handler(Looper.getMainLooper())
    private val fmt = SimpleDateFormat("MMM d  HH:mm", Locale.getDefault())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun res(n: String) = resources.getIdentifier(n, "drawable", packageName)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel("bar", "Status bar", NotificationManager.IMPORTANCE_MIN)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        startForeground(1, Notification.Builder(this, "bar").setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("NeoBar running").build())

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val barH = dp(26)
        bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), 0, dp(6), 0)
            // webOS-style light gradient
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFFF4F4F4.toInt(), 0xFFC9C9C9.toInt()))
        }
        left = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        clock = TextView(this).apply { setTextColor(0xFF333333.toInt()); textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(6), 0, 0, 0) }
        fun icon(w: Int, hh: Int) = ImageView(this).apply { layoutParams = LinearLayout.LayoutParams(dp(w), dp(hh)).apply { marginStart = dp(5) } }
        bt = icon(16, 18).apply { setImageResource(res("ic_bt")) }
        net = icon(18, 18).apply { setImageResource(res("ic_3g")) }
        sig = icon(20, 16).apply { setImageResource(res("ic_signal")) }
        batt = icon(38, 18)
        bar.addView(left); bar.addView(clock)
        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        listOf(bt, net, sig, batt).forEach { bar.addView(it) }

        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, barH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP }
        wm.addView(bar, lp)

        registerReceiver(object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) = updBattery(i) },
            IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        NotifService.onChange = { icons -> h.post { showIcons(icons) } }
        tick()
    }

    // Battery sprite: 110 frames (0..109) sliced from the sheet -> map 0-100%
    private fun updBattery(i: Intent) {
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        batt.setImageResource(res("bat_%03d".format(lvl * 109 / 100)))
    }

    private fun showIcons(icons: List<Drawable>) {
        left.removeAllViews()
        icons.take(6).forEach { d ->
            left.addView(ImageView(this).apply {
                setImageDrawable(d); setColorFilter(0xFF222222.toInt())
                layoutParams = LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginEnd = dp(3) } })
        }
    }

    private fun tick() {
        clock.text = fmt.format(Date())
        val cm = getSystemService(ConnectivityManager::class.java)
        val c = cm.getNetworkCapabilities(cm.activeNetwork)
        net.alpha = if (c?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true) 1f else 0.3f
        sig.alpha = if (c != null) 1f else 0.3f
        val ad = BluetoothAdapterHelper.on(this); bt.alpha = if (ad) 1f else 0.3f
        h.postDelayed({ tick() }, 15000)
    }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); NotifService.onChange = null; wm.removeView(bar); super.onDestroy() }
}

object BluetoothAdapterHelper {
    fun on(c: Context) = runCatching { c.getSystemService(android.bluetooth.BluetoothManager::class.java).adapter?.isEnabled == true }.getOrDefault(false)
}
