package com.example.neobar
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS", "android.permission.BLUETOOTH_CONNECT"), 1)
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48)
            addView(btn("1. Allow draw over other apps") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) })
            addView(btn("2. Allow notification access (left-side icons)") {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) })
            addView(btn("3. Start status bar") {
                if (Settings.canDrawOverlays(this@MainActivity)) startForegroundService(Intent(this@MainActivity, BarService::class.java)) })
            addView(btn("Stop status bar") { stopService(Intent(this@MainActivity, BarService::class.java)) })
        })
    }
}
